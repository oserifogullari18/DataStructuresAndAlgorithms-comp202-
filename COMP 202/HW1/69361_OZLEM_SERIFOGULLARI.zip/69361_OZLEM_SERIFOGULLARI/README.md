[![Work in Repl.it](https://classroom.github.com/assets/work-in-replit-14baed9a392b3a25080506f3b7b6d57f295ec2978f6f33ec97e36a161684cbe9.svg)](https://classroom.github.com/online_ide?assignment_repo_id=4410265&assignment_repo_type=AssignmentRepo)
# comp202_2021_spring_HW1

Note: In case you are using repl.it, type first "javac *.java" to be able to run HW1.java file

You only need to work on the HW1.java file
The file containing "test" in the name is only needed for github autograding tests. To see the results of the test open the |Actions| tab
